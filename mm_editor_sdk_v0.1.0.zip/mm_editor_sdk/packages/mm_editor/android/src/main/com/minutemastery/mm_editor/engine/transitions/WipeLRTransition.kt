# packages/mm_editor/android/src/main/com/minutemastery/mm_editor/engine/transitions/WipeLRTransition.kt

package com.minutemastery.mm_editor.engine.transitions

class WipeLRTransition : Transition {
    override val ffmpegName = "wipe_lr"
}