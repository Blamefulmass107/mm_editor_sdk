# packages/mm_editor/android/src/main/com/minutemastery/mm_editor/engine/transitions/SlideLRTransition.kt

package com.minutemastery.mm_editor.engine.transitions

class SlideLRTransition : Transition {
    override val ffmpegName = "slide_lr"
}