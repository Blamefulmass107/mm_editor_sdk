# packages/mm_editor/android/src/main/com/minutemastery/mm_editor/engine/transitions/SlideRLTransition.kt

package com.minutemastery.mm_editor.engine.transitions

class SlideRLTransition : Transition {
    override val ffmpegName = "slide_rl"
}