# packages/mm_editor/android/src/main/com/minutemastery/mm_editor/engine/transitions/DipWhiteTransition.kt

package com.minutemastery.mm_editor.engine.transitions

class DipWhiteTransition : Transition {
    override val ffmpegName = "fadewhite"
}
