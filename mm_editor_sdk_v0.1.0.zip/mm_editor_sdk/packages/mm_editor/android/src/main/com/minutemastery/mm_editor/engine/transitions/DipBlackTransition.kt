# packages/mm_editor/android/src/main/com/minutemastery/mm_editor/engine/transitions/DipBlackTransition.kt

package com.minutemastery.mm_editor.engine.transitions

class DipBlackTransition : Transition {
    override val ffmpegName = "fadeblack"
}
