# packages/mm_editor/ios/Classes/engine/transitions/WipeLRTransition.swift

toLayer.setOpacityRamp(0→1)
fromLayer.setOpacityRamp(1→0)
